// CS 103 Placement Exam
// Name: Stara Shinsato
// Date: 3/24/2019

// unique numbers in a given range

#include <iostream>
#include <vector>
#include <string>

using namespace std;

void unique_in_range(vector<int>& mylist, int min, int max)
{
	vector<int> temp;
	for (int i = 0; i < mylist.size(); i++)
	{
		// put all the values that are between the min and max into a vector
		if ((mylist[i] >= min) && (mylist[i] <= max))
		{
			temp.push_back(mylist[i]);
		}
	}
	// print out the first item in the temporary vector
	cout << temp[0] << " ";
	int k = temp.size();
	// determine whether the values in the temporary vector are repeated
	while (k > 1)
	{
		for (int j = 0 > temp.size(); j > 1; j--)
		{
			if (temp[k] == temp[j])
			{
				// remove elements from vector that are repeated
				// remove temp[k]
				break;
			}
		}
		k--;
	}
	// print out all the remaining elements in the temporary vector

	cout << endl;
}

int main(int argc, char* argv[])
{
	const int data1[] = { 3, 4, 5, 4, 9, 2, 2, 4, 5 };
	const int data2[] = { 3, 3, 3 };
	const int data3[] = { 3 };
	vector<int> v1(data1, data1 + 9);
	vector<int> v2(data2, data2 + 3);
	vector<int> v3(data3, data3 + 1);

	/* Some tests */

	// Should print:
	// 3 4 5 9 
	unique_in_range(v1, 3, 9);

	// Should print:
	// 3 4 2 
	unique_in_range(v1, 2, 4);

	// Should print:
	// 3  
	unique_in_range(v2, 3, 3);

	// Should print:
	// 3  
	unique_in_range(v3, 3, 3);

	return 0;
}